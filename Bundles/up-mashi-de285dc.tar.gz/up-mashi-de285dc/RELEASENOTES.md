#Release Notes
Mashi Timeline Toolkit 	
(http://mashi.tv/REALESENOTES.md) 

-------------------------------------------------------------------------------
####[2011-06-11: VERSION 1.0.0 - REVISION 21]
**********************

[FIXED] 'isReady' BUG in IE9

-------------------------------------------------------------------------------
####[2011-05-03: VERSION 1.0.0 - REVISION 20]
**********************

Second public release.

[CHANGED] Almost everything.

-------------------------------------------------------------------------------
####[2010-08-24: VERSION 0.9.3 - REVISION 12]
**********************

First public release.
